### Project 4: Server Deployment, Containerization and Testing

Application has been teared down after successfull review to avoid incurring additional costs.

[View Project](https://github.com/Thalrion/FSND-Deploy-Flask-App-to-Kubernetes-Using-EKS).